import UIKit

//var str = "Hello, playground"
//
//
////var phone1 = "iPhone X"
////var phone2 = "SamSung"
////var phone3 = "Pixel 3XL"
//
//var phones = ["iPhone X", "Samsung", "Pixel 3XL"]
//
//phones[0]
//
//phones.append("HTC")

//print(phones[0])

//for index in 0...3 {
//    print(phones[index])
//}

//for index in 0...phones.count - 1 {
//    print(phones[index])
//}

//for index in phones {
//    print(index)
//}


//let name: String? = "Yamusa Dalhatu"
//print(name?.count ?? 0)

//var name2: String? = "Yamusa Dalhatu"
//if name2 != nil{
//    print(name2 ?? 0)
//} // optional binding
//
//print(name2!.count) // Forcefully unwrapping optional

// Optionals
// Optional binding
// Unwrapping optionals
// Optional chaining
